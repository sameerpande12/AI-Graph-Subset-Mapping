g++ -std=c++0x run1.cpp -o run1
g++ -std=c++0x run2.cpp -o run2
