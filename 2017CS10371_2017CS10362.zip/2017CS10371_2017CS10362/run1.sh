./run1 $1 < $1.graphs
rm $1_temp.satinput
#header=$(head -1 header.txt)
#sed -i "1i ${header}" $1.satinput
